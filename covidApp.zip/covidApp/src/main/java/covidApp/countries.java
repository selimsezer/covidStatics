package covidApp;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

import covidApp.contryInfo.countryInfo;

public class countries implements countryInfo {
	protected String countryName;
	protected String responses;
	protected HttpResponse<String> response;

	public countries(String countryName) throws UnirestException {
		this.countryName = countryName;
		Unirest.setTimeouts(0, 0);
		this.response = Unirest
				.get("https://disease.sh/v3/covid-19/countries/" + countryName + "?yesterday=true&strict=true")
				.asString();

		this.responses = response.getBody();
	}

	public String allStatics() throws UnirestException {
		Unirest.setTimeouts(0, 0);
		HttpResponse<String> response2 = Unirest.get("https://disease.sh/v3/covid-19/all").asString();
		String responseAll = response2.getBody();
		String[] container = responseAll.split(",");
		String totalCases = container[1];
		String todayCases = container[2];
		String totalDeaths = container[3];
		String todayDeaths = container[4];
		String totalRecovered = container[5];
		String todayRecovered = container[6];
		String totalTests = container[11];
		String edited = "<html><h1>World Live Statics</h1><p>" + totalCases + "&nbsp; &nbsp; &nbsp; &nbsp;" + totalDeaths
				+ "&nbsp; &nbsp; &nbsp; &nbsp;" + totalRecovered + "</p><p>" + todayCases
				+ "&nbsp; &nbsp; &nbsp; &nbsp;" + todayDeaths + "&nbsp; &nbsp; &nbsp; &nbsp;" + todayRecovered
				+ "</p><html>";

		return edited;
	}

	public int totalCase() {
		String[] container = responses.split(",");
		String[] totalCaseDept = container[8].split(":");

		int totalCase = Integer.parseInt(totalCaseDept[1]);
		return totalCase;
	}

	public int totalDeath() {
		String[] container = responses.split(",");
		String[] totalDeathDept = container[10].split(":");

		int totalDeath = Integer.parseInt(totalDeathDept[1]);
		return totalDeath;
	}

	public int totalRecovered() {
		String[] container = responses.split(",");
		String[] totalRecoDept = container[12].split(":");

		int totalRecovered = Integer.parseInt(totalRecoDept[1]);
		return totalRecovered;
	}

	public int dailyCase() {
		String[] container = responses.split(",");
		String[] dailyCaseDept = container[9].split(":");

		int dailyCase = Integer.parseInt(dailyCaseDept[1]);
		return dailyCase;

	}

	public int dailyDeath() {
		String[] container = responses.split(",");
		String[] dailyDeathDept = container[11].split(":");

		int dailyDeath = Integer.parseInt(dailyDeathDept[1]);
		return dailyDeath;
	}

	public int dailyRecovered() {
		String[] container = responses.split(",");
		String[] dailyRecoveredDept = container[13].split(":");

		int dailyRecovered = Integer.parseInt(dailyRecoveredDept[1]);
		return dailyRecovered;
	}

	public String flag() {
		String[] container = responses.split(",");
		String[] flagurl = container[7].split(":");
		String url = flagurl[1];
		return url;
	}

	public Date yesterday() {
		final Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		return cal.getTime();
	}

	public String getYesterdayDateString() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		return dateFormat.format(yesterday());
	}
}
