package covidApp;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;

import org.apache.http.nio.protocol.ThrottlingHttpServiceHandler;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.mashape.unirest.http.exceptions.UnirestException;

import javax.swing.JSeparator;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Set;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class menus {
	private Logger logger = LogManager.getLogger(menus.class);
	private JFrame frame;
	private final JButton fr_button = new JButton("France");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		Logger logger = LogManager.getLogger(menus.class);
		connect connect = new connect();
		try {
			connect.franceInfo();
			connect.germanyInfo();
			connect.italyInfo();
			connect.turkeyInfo();
			connect.polandInfo();
			connect.spainInfo();
		} catch (UnirestException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			logger.warn("Database or internet connection error");
			
		}

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					menus window = new menus();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
					logger.warn("GUI error");
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public menus() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 443, 339);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);

		fr_button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				franceWindow franceWindow;
				try {
					franceWindow = new franceWindow();
					franceWindow.setVisible(true);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (UnirestException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});

		fr_button.setBounds(10, 80, 116, 48);
		panel.add(fr_button);

		JButton es_buttton = new JButton("Spain");
		es_buttton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				esWindow esWindow;
				try {
					esWindow = new esWindow();
					esWindow.setVisible(true);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					logger.error("Window can not open.");
				} catch (UnirestException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		es_buttton.setBounds(10, 139, 116, 48);
		panel.add(es_buttton);

		JButton pl_button = new JButton("Poland");
		pl_button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				plWindow plWindow;
				try {
					plWindow = new plWindow();
					plWindow.setVisible(true);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (UnirestException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		pl_button.setBounds(153, 80, 116, 48);
		panel.add(pl_button);

		JButton tr_button = new JButton("Turkey");
		tr_button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				trWindow trWindow;
				try {
					trWindow = new trWindow();
					trWindow.setVisible(true);
					turkey turkey = new turkey();

				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (UnirestException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		tr_button.setBounds(153, 139, 116, 48);
		panel.add(tr_button);

		JButton gr_button = new JButton("Germany");
		gr_button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				deWindow deWindow;
				try {
					deWindow = new deWindow();
					deWindow.setVisible(true);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (UnirestException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		gr_button.setBounds(301, 80, 116, 48);
		panel.add(gr_button);

		JButton it_button = new JButton("Italy");
		it_button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				itWindow itWindow;
				try {
					itWindow = new itWindow();
					itWindow.setVisible(true);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (UnirestException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		it_button.setBounds(301, 139, 116, 48);
		panel.add(it_button);
		try {
			countries countries = new france();

			JLabel all_label = new JLabel("World Statics");
			all_label.setText(countries.allStatics());
			all_label.setHorizontalAlignment(SwingConstants.CENTER);
			all_label.setFont(new Font("Tahoma", Font.PLAIN, 11));
			all_label.setBounds(10, 207, 414, 88);
			panel.add(all_label);
		} catch (UnirestException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			logger.fatal("World statics unavaible");
		}

		JSeparator separator = new JSeparator();
		separator.setBounds(10, 198, 414, 2);
		panel.add(separator);

		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 67, 414, 2);
		panel.add(separator_1);

		JLabel Header = new JLabel("COVID19 STATICS");
		Header.setFont(new Font("Tahoma", Font.PLAIN, 41));
		Header.setHorizontalAlignment(SwingConstants.CENTER);
		Header.setBounds(10, 11, 414, 45);
		panel.add(Header);

	}
}
