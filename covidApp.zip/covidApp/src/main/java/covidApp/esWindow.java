package covidApp;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mashape.unirest.http.exceptions.UnirestException;

import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class esWindow extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			esWindow dialog = new esWindow();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 * @throws IOException 
	 * @throws UnirestException 
	 */
	public esWindow() throws IOException, UnirestException {
		setBounds(100, 100, 503, 362);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel Staticss = new JLabel("");
		Staticss.setFont(new Font("Tahoma", Font.PLAIN, 21));
		Staticss.setHorizontalAlignment(SwingConstants.CENTER);
		Staticss.setBounds(10, 11, 464, 164);
		countries info = new spain();
		String labelInfo = "<html><p>Daily Case: " + info.dailyCase() +"Daily Death: " + info.dailyDeath() + "Daily Recovered: " + info.dailyRecovered()
		+"<p><p>Total Case: " + info.totalCase() + "Total Death: " + info.totalDeath() + "Total Recovered: " + info.totalRecovered();
		Staticss.setText("<html><p>Daily Case: 7656   Daily Death: 137    Daily Recovered: 11180<p><p>Total Case: 5235978   Total Death: 47271   Total Recovered: 5094279");

		contentPanel.add(Staticss);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 186, 464, 2);
		contentPanel.add(separator);
		
		JButton btnBarchart = new JButton("BarChart");
		btnBarchart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					esBarChart esBarChart = new esBarChart();
					esBarChart.setVisible(true);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnBarchart.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnBarchart.setBounds(165, 221, 150, 51);
		contentPanel.add(btnBarchart);

	}
}
