package covidApp;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GradientPaint;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.ui.ApplicationFrame;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import com.mashape.unirest.http.exceptions.UnirestException;

import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javax.swing.JSpinner;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;
import java.awt.Dialog.ModalityType;
import java.awt.SystemColor;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class itWindow extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 * 
	 * @throws IOException
	 * @throws UnirestException
	 */
	public static void main(String[] args) throws IOException, UnirestException {
		try {
			itWindow dialog = new itWindow();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
			;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 * 
	 * @throws IOException
	 * @throws UnirestException 
	 */
	@SuppressWarnings("deprecation")
	public itWindow() throws IOException, UnirestException {
		setTitle("Turkey");
		setModalityType(ModalityType.APPLICATION_MODAL);
		setBounds(100, 100, 500, 300);
		FlowLayout fl_contentPanel = new FlowLayout();
		fl_contentPanel.setAlignOnBaseline(true);
		contentPanel.setBounds(0, 0, 0, 0);
		contentPanel.setLayout(fl_contentPanel);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
			
		JLabel Staticss = new JLabel("");
		Staticss.setFont(new Font("Tahoma", Font.PLAIN, 21));
		Staticss.setHorizontalAlignment(SwingConstants.CENTER);
		Staticss.setBounds(10, 11, 464, 164);
		Staticss.setBackground(SystemColor.inactiveCaptionBorder);
		getContentPane().setLayout(null);
		getContentPane().add(contentPanel);
		getContentPane().add(Staticss);
		getContentPane().setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{contentPanel}));
		setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{getContentPane(), contentPanel}));
		countries info = new italy();
		String labelInfo = "<html><p>Daily Case: " + info.dailyCase() +"Daily Death: " + info.dailyDeath() + "Daily Recovered: " + info.dailyRecovered()
		+"<p><p>Total Case: " + info.totalCase() + "Total Death: " + info.totalDeath() + "Total Recovered: " + info.totalRecovered();
		Staticss.setText("<html><p>Daily Case: 7656   Daily Death: 137    Daily Recovered: 11180<p><p>Total Case: 5235978   Total Death: 47271   Total Recovered: 5094279");
		
		JButton chartButton = new JButton("Bar Chart");
		chartButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					itBarChart itBarChart;
					try {
						itBarChart = new itBarChart();
						itBarChart.setVisible(true);
					
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		chartButton.setFont(new Font("Tahoma", Font.PLAIN, 17));
		chartButton.setBounds(164, 199, 150, 51);
		getContentPane().add(chartButton);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 186, 464, 2);
		getContentPane().add(separator);
	}
}
