package covidApp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.mashape.unirest.http.exceptions.UnirestException;

public class connect {
	Logger logger = LogManager.getLogger(connect.class);

	public Connection connection() {
		String url = "jdbc:sqlite:C://Users/selim/eclipse-workspace/covidApp/database/vakaSayilari.db";
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(url);
			logger.info("Database connection succesfully");
		} catch (SQLException e) {
			e.getStackTrace();
			System.out.println(e.getMessage());
			logger.fatal("Database Connection error");

		}
		return conn;
	}

	public void germanyInfo() throws UnirestException {
		countries de = new germany();
		String insertSql = "INSERT INTO Germany(Date,DailyCase, DailyDeath, DailyRecovered, TotalCase, TotalDeath, TotalRecovered) VALUES(?,?,?,?,?,?,?)";

		try (Connection conn = this.connection();

				PreparedStatement pStatement = conn.prepareStatement(insertSql)) {
			pStatement.setString(1, de.getYesterdayDateString());
			pStatement.setInt(2, de.dailyCase());
			pStatement.setInt(3, de.dailyDeath());
			pStatement.setInt(4, de.dailyRecovered());
			pStatement.setInt(5, de.totalCase());
			pStatement.setInt(6, de.totalDeath());
			pStatement.setInt(7, de.totalRecovered());
			pStatement.executeUpdate();
		} catch (SQLException e) {
			logger.fatal("Database does not updated");
		}
	}

	public void franceInfo() throws UnirestException {
		countries fr = new france();
		String insertSql = "INSERT INTO France(Date,DailyCase, DailyDeath, DailyRecovered, TotalCase, TotalDeath, TotalRecovered) VALUES(?,?,?,?,?,?,?)";

		try (Connection conn = this.connection(); PreparedStatement pStatement = conn.prepareStatement(insertSql)) {
			pStatement.setString(1, fr.getYesterdayDateString());
			pStatement.setInt(2, fr.dailyCase());
			pStatement.setInt(3, fr.dailyDeath());
			pStatement.setInt(4, fr.dailyRecovered());
			pStatement.setInt(5, fr.totalCase());
			pStatement.setInt(6, fr.totalDeath());
			pStatement.setInt(7, fr.totalRecovered());
			pStatement.executeUpdate();
		} catch (SQLException e) {
			e.getStackTrace();
			logger.fatal("Database does not updated");
		}
	}

	public void polandInfo() throws UnirestException {
		countries ct = new poland();
		String insertSql = "INSERT INTO Poland(Date,DailyCase, DailyDeath, DailyRecovered, TotalCase, TotalDeath, TotalRecovered) VALUES(?,?,?,?,?,?,?)";

		try (Connection conn = this.connection(); PreparedStatement pStatement = conn.prepareStatement(insertSql)) {
			pStatement.setString(1, ct.getYesterdayDateString());
			pStatement.setInt(2, ct.dailyCase());
			pStatement.setInt(3, ct.dailyDeath());
			pStatement.setInt(4, ct.dailyRecovered());
			pStatement.setInt(5, ct.totalCase());
			pStatement.setInt(6, ct.totalDeath());
			pStatement.setInt(7, ct.totalRecovered());
			pStatement.executeUpdate();
		} catch (SQLException e) {
			e.getStackTrace();
			logger.fatal("Database does not updated");
		}
	}

	public void turkeyInfo() throws UnirestException {
		countries ct = new turkey();
		String insertSql = "INSERT INTO Turkey(Date,DailyCase, DailyDeath, DailyRecovered, TotalCase, TotalDeath, TotalRecovered) VALUES(?,?,?,?,?,?,?)";

		try (Connection conn = this.connection(); PreparedStatement pStatement = conn.prepareStatement(insertSql)) {
			pStatement.setString(1, ct.getYesterdayDateString());
			pStatement.setInt(2, ct.dailyCase());
			pStatement.setInt(3, ct.dailyDeath());
			pStatement.setInt(4, ct.dailyRecovered());
			pStatement.setInt(5, ct.totalCase());
			pStatement.setInt(6, ct.totalDeath());
			pStatement.setInt(7, ct.totalRecovered());
			pStatement.executeUpdate();
		} catch (SQLException e) {
			e.getStackTrace();
			logger.fatal("Database does not updated");
		}
	}

	public void spainInfo() throws UnirestException {
		countries ct = new spain();
		String insertSql = "INSERT INTO Spain(Date,DailyCase, DailyDeath, DailyRecovered, TotalCase, TotalDeath, TotalRecovered) VALUES(?,?,?,?,?,?,?)";

		try (Connection conn = this.connection(); PreparedStatement pStatement = conn.prepareStatement(insertSql)) {
			pStatement.setString(1, ct.getYesterdayDateString());
			pStatement.setInt(2, ct.dailyCase());
			pStatement.setInt(3, ct.dailyDeath());
			pStatement.setInt(4, ct.dailyRecovered());
			pStatement.setInt(5, ct.totalCase());
			pStatement.setInt(6, ct.totalDeath());
			pStatement.setInt(7, ct.totalRecovered());
			pStatement.executeUpdate();
		} catch (SQLException e) {
			e.getStackTrace();
			logger.fatal("Database does not updated");
		}
	}

	public void italyInfo() throws UnirestException {
		countries ct = new italy();
		String insertSql = "INSERT INTO France(Date,DailyCase, DailyDeath, DailyRecovered, TotalCase, TotalDeath, TotalRecovered) VALUES(?,?,?,?,?,?,?)";

		try (Connection conn = this.connection(); PreparedStatement pStatement = conn.prepareStatement(insertSql)) {
			pStatement.setString(1, ct.getYesterdayDateString());
			pStatement.setInt(2, ct.dailyCase());
			pStatement.setInt(3, ct.dailyDeath());
			pStatement.setInt(4, ct.dailyRecovered());
			pStatement.setInt(5, ct.totalCase());
			pStatement.setInt(6, ct.totalDeath());
			pStatement.setInt(7, ct.totalRecovered());
			pStatement.executeUpdate();
		} catch (SQLException e) {
			e.getStackTrace();
			logger.fatal("Database does not updated");
		}
	}
}
