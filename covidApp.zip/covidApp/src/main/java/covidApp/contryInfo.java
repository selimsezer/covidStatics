package covidApp;

public interface contryInfo {
	public interface countryInfo {
		String getYesterdayDateString();

		int totalCase();

		int totalDeath();

		int totalRecovered();

		int dailyCase();

		int dailyDeath();

		int dailyRecovered();
	}
}
