package covidApp;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mashape.unirest.http.exceptions.UnirestException;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class deWindow extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			deWindow dialog = new deWindow();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 * @throws IOException 
	 * @throws UnirestException 
	 */
	public deWindow() throws IOException, UnirestException {
		setBounds(100, 100, 502, 323);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel staticss = new JLabel("");
		staticss.setHorizontalAlignment(SwingConstants.CENTER);
		staticss.setFont(new Font("Tahoma", Font.PLAIN, 21));
		staticss.setBounds(10, 11, 466, 164);
		contentPanel.add(staticss);
		countries info = new germany();
		String labelInfo = "<html><p>Daily Case: " + info.dailyCase() +"Daily Death: " + info.dailyDeath() + "Daily Recovered: " + info.dailyRecovered()
		+"<p><p>Total Case: " + info.totalCase() + "Total Death: " + info.totalDeath() + "Total Recovered: " + info.totalRecovered();
		staticss.setText("<html><p>Daily Case: 7656   Daily Death: 137    Daily Recovered: 11180<p><p>Total Case: 5235978   Total Death: 47271   Total Recovered: 5094279");

		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 186, 466, 2);
		contentPanel.add(separator);
		
		JButton btnBarChart = new JButton("Bar Chart");
		btnBarChart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					deBarChart deBarChart = new deBarChart();
					deBarChart.setVisible(true);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnBarChart.setBounds(160, 210, 150, 51);
		contentPanel.add(btnBarChart);
		
	}

}
