package covidApp;

import java.awt.RenderingHints;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.sun.javafx.binding.StringFormatter;
import com.sun.swing.internal.plaf.basic.resources.basic;

import sun.security.krb5.KdcComm;
import sun.security.util.ArrayUtil;

public class turkey extends countries {
	protected String report;
	protected HttpResponse<String> response;
	private String[] dates = { "a", "b", "c", "d", "e", "f", "g" };
	private String[] container;

	public turkey() throws UnirestException {
		super("TR");
		super.getYesterdayDateString();
		super.dailyCase();
		super.dailyDeath();
		super.dailyRecovered();
		super.totalCase();
		super.totalDeath();
		super.totalRecovered();
		Unirest.setTimeouts(0, 0);
		this.response = Unirest.get("https://disease.sh/v3/covid-19/historical/TR?lastdays=7").asString();

		this.report = response.getBody();
		this.container = report.split(",");
	}

	public String[] lastWeekDays() throws UnirestException {
		String[] date2 = { "a", "b", "c", "d", "e", "f", "g" };
		int datesElmt = 0;
		for (int i = 2; i < 9; i++) {
			String dateS = this.container[i];
			date2[datesElmt] = dateS;
			datesElmt++;
		}
		for (int i = 0; i < 7; i++) {
			int a = 2;
			int b = 3;
			String[] tried2 = date2[i].split(":");
			if (i == 0) {
				String tried3 = tried2[a];
				this.dates[i] = tried3;
			} else {
				a = 0;
				b = 1;
				String tried3 = tried2[a];
				this.dates[i] = tried3;
			}
		}
		return this.dates;
	}

	public int[] lastWeekCases() {
		int[] caseStt = { 0, 0, 0, 0, 0, 0, 0 };
		int caseIndex = 0;
		int caseTry = 0;
		for (int i = 2; i < 9; i++) {
			String tried = container[i];
			String[] triedArr = tried.split(":");
			if (i == 2) {
				caseTry = Integer.parseInt(triedArr[3]);
			}
			else if (i == 8) {
				String lc = triedArr[1].substring(0, triedArr[1].length() - 1);
				caseTry = Integer.parseInt(lc);
			}else {
				caseTry = Integer.parseInt(triedArr[1]);
			}		
			caseStt[caseIndex] = caseTry;
			caseIndex++;
		}
		return caseStt;
	}

	public int[] lastWeekDeath() {
		int[] deathStt = { 0, 0, 0, 0, 0, 0, 0 };
		int deathIndex = 0;
		int deathTry = 0;
		for (int i = 9; i < 16; i++) {
			String tried = container[i];
			String[] triedArr = tried.split(":");
			if (i == 9) {
				deathTry = Integer.parseInt(triedArr[2]);
			} else if (i == 15) {
				String lc = triedArr[1].substring(0, triedArr[1].length() - 1);
				deathTry = Integer.parseInt(lc);
			} else {
				deathTry = Integer.parseInt(triedArr[1]);
			}
			deathStt[deathIndex] = deathTry;
			deathIndex++;
		}
		return deathStt;
	}

	public int[] lastWeekRecovered() {
		int[] recoveredStt = { 0, 0, 0, 0, 0, 0, 0 };
		int recoIndex = 0;
		int recoTry = 0;
		for (int i = 16; i < 23; i++) {
			String tried = container[i];
			String[] triedArr = tried.split(":");
			if (i == 16) {
				recoTry = Integer.parseInt(triedArr[2]);
			} else if (i == 22) {
				String lc = triedArr[1].substring(0, triedArr[1].length() - 3);
				recoTry = Integer.parseInt(lc);
			} else {
				recoTry = Integer.parseInt(triedArr[1]);
			}
			recoveredStt[recoIndex] = recoTry;
			recoIndex++;
		}
		return recoveredStt;
	}

}
