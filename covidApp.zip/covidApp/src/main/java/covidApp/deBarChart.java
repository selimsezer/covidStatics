package covidApp;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import com.mashape.unirest.http.exceptions.UnirestException;

import covidApp.turkey;
import javax.swing.ImageIcon;


public class deBarChart extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 * 
	 * @throws UnirestException
	 * @throws IOException 
	 */
	public static void main(String[] args) throws UnirestException, IOException {
		germany turkey = new germany();
		String[] dates = turkey.lastWeekDays();
		int[] caseS = turkey.lastWeekCases();
		int[] deathS = turkey.lastWeekDeath();
		int[] recoveredS = turkey.lastWeekRecovered();
		
		final String cases = "Cases";
		final String death = "Death";
		final String Recovered = "Recovered";
		final String day1 = dates[0];
		final String day3 = dates[1];
		final String day2 = dates[2];
		final String day4 = dates[3];
		final String day5 = dates[4];
		final String day6 = dates[5];
		final String day7 = dates[6];

		final DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		dataset.addValue(caseS[0], cases, day1);
		dataset.addValue(caseS[1], cases, day2);
		dataset.addValue(caseS[2], cases, day3);
		dataset.addValue(caseS[3], cases, day4);
		dataset.addValue(caseS[4], cases, day5);
		dataset.addValue(caseS[5], cases, day6);
		dataset.addValue(caseS[6], cases, day7);

		dataset.addValue(deathS[0], death, day1);
		dataset.addValue(deathS[1], death, day2);
		dataset.addValue(deathS[2], death, day3);
		dataset.addValue(deathS[3], death, day4);
		dataset.addValue(deathS[4], death, day5);
		dataset.addValue(deathS[5], death, day6);
		dataset.addValue(deathS[6], death, day7);

		dataset.addValue(recoveredS[0], Recovered, day1);
		dataset.addValue(recoveredS[1], Recovered, day2);
		dataset.addValue(recoveredS[2], Recovered, day3);
		dataset.addValue(recoveredS[3], Recovered, day4);
		dataset.addValue(recoveredS[4], Recovered, day5);
		dataset.addValue(recoveredS[5], Recovered, day6);
		dataset.addValue(recoveredS[6], Recovered, day7);
		
		 Image icon = ImageIO.read(new File("C://Users/selim/eclipse-workspace/covidApp/de_flag.jpg"));

		JFreeChart barChart = ChartFactory.createBarChart("GERMANY COVID19 STATISTICS", "Date", "People", dataset,
				PlotOrientation.VERTICAL, true, true, false);
		
        barChart.setBackgroundImage(icon);
        Color trans = new Color(0xFF, 0xFF, 0xFF, 0);
        barChart.getPlot().setBackgroundPaint( trans );
        barChart.getPlot().setOutlineVisible(false);
		

		int width = 640; /* Width of the image */
		int height = 480; /* Height of the image */
		File BarChart = new File("deBarChart.jpeg");
		ChartUtilities.saveChartAsJPEG(BarChart, barChart, width, height);

		try {
			deBarChart dialog = new deBarChart();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 * @throws IOException 
	 */
	public deBarChart() throws IOException {
		setBounds(100, 100, 660, 525);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		BufferedImage charts = ImageIO.read(new File("C://Users/selim/eclipse-workspace/covidApp/deBarChart.jpeg"));
		JLabel chartss = new JLabel();
		chartss.setIcon(new ImageIcon("C:\\Users\\selim\\eclipse-workspace\\covidApp\\deBarChart.jpeg"));
		getContentPane().add(chartss);
	
	}

}